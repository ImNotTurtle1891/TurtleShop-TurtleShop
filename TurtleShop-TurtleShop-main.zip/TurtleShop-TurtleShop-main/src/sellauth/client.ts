import type {
  AbandonedCheckoutPage,
  AbandonedCheckoutStats,
  ActivityLogPage,
  AffiliateDetail,
  AffiliatePage,
  AffiliatePayoutPage,
  AffiliateStats,
  AffiliateTier,
  AnalyticsSummary,
  BalanceTransactionPage,
  BlacklistEntry,
  BlacklistLogPage,
  BlacklistPage,
  LatestNotifications,
  PaymentMethod,
  ResellerDetail,
  ResellerPage,
  ResellerStats,
  ResellerTier,
  SubscriptionDetail,
  SubscriptionPage,
  TrafficStats,
  TrafficUtmBreakdown,
  UpdateCouponInput,
  WebhookLogPage,
  WhitelistEntry,
  WhitelistPage,
  CheckoutSession,
  Coupon,
  CreateBlacklistEntryInput,
  CreateCheckoutInput,
  CouponPage,
  CreateCouponInput,
  CustomerPage,
  CustomerSummary,
  DateRange,
  FeedbackListQuery,
  FeedbackPage,
  FeedbackStats,
  Invoice,
  InvoicePage,
  ProductDetail,
  ProductListQuery,
  ProductPage,
  ShopStats,
  TicketDetail,
  TicketListQuery,
  TicketPage,
  TopCustomer,
  TopPaymentMethod,
  TopProduct
} from './types.js';

type QueryParams = Readonly<Record<string, string>>;

function dateRangeParams(range: DateRange): QueryParams {
  return { start: range.start, end: range.end };
}

export class SellAuthApiError extends Error {
  public readonly status: number;
  /** Short human-readable error from the API response body, when available. */
  public readonly apiMessage: string | null;

  public constructor(status: number, message: string, apiMessage: string | null = null) {
    super(message);
    this.name = 'SellAuthApiError';
    this.status = status;
    this.apiMessage = apiMessage;
  }
}

function extractApiMessage(body: string): string | null {
  try {
    const parsed = JSON.parse(body) as { error?: unknown; message?: unknown };
    const candidate = parsed.error ?? parsed.message;
    return typeof candidate === 'string' && candidate !== '' ? candidate : null;
  } catch {
    return null;
  }
}

export interface SellAuthClientOptions {
  readonly apiKey: string;
  readonly shopId: string;
  readonly baseUrl: string;
}

export class SellAuthClient {
  private readonly apiKey: string;
  private readonly shopId: string;
  private readonly baseUrl: string;

  public constructor(options: SellAuthClientOptions) {
    this.apiKey = options.apiKey;
    this.shopId = options.shopId;
    this.baseUrl = options.baseUrl;
  }

  public async getShopStats(): Promise<ShopStats> {
    return this.get<ShopStats>('/stats');
  }

  public async getAnalytics(range: DateRange): Promise<AnalyticsSummary> {
    return this.get<AnalyticsSummary>('/analytics', dateRangeParams(range));
  }

  public async getTopProducts(range: DateRange): Promise<TopProduct[]> {
    return this.get<TopProduct[]>('/analytics/top-products', dateRangeParams(range));
  }

  public async getTopCustomers(range: DateRange): Promise<TopCustomer[]> {
    return this.get<TopCustomer[]>('/analytics/top-customers', dateRangeParams(range));
  }

  public async getTopPaymentMethods(range: DateRange): Promise<TopPaymentMethod[]> {
    return this.get<TopPaymentMethod[]>('/analytics/top-payment-methods', dateRangeParams(range));
  }

  public async getProducts(query: ProductListQuery): Promise<ProductPage> {
    const params: Record<string, string> = {
      page: String(query.page),
      perPage: String(query.perPage)
    };
    if (query.name !== undefined) {
      params['name'] = query.name;
    }
    return this.get<ProductPage>('/products', params);
  }

  public async getProduct(productId: number): Promise<ProductDetail> {
    return this.get<ProductDetail>(`/products/${productId}`);
  }

  /** Returns the undelivered serial keys of a serials-type product variant. */
  public async getDeliverables(productId: number, variantId: number): Promise<readonly string[]> {
    const result = await this.get<unknown>(`/products/${productId}/deliverables/${variantId}`);
    // Non-serials products return an empty object instead of an array.
    return Array.isArray(result) ? (result as readonly string[]) : [];
  }

  public async appendDeliverables(
    productId: number,
    variantId: number,
    deliverables: readonly string[]
  ): Promise<void> {
    await this.request('PUT', `/products/${productId}/deliverables/append/${variantId}`, {
      body: { deliverables }
    });
  }

  /** Accepts either the numeric invoice ID or the customer-facing unique ID. */
  public async getInvoice(invoiceId: string): Promise<Invoice> {
    return this.get<Invoice>(`/invoices/${encodeURIComponent(invoiceId)}`);
  }

  public async updateInvoiceStatus(
    invoiceId: number,
    status: 'completed' | 'cancelled' | 'failed' | 'refunded'
  ): Promise<void> {
    await this.request('POST', `/invoices/${invoiceId}/status`, { body: { status } });
  }

  public async refundInvoice(invoiceId: number): Promise<void> {
    await this.request('POST', `/invoices/${invoiceId}/refund`);
  }

  public async cancelInvoice(invoiceId: number): Promise<void> {
    await this.request('POST', `/invoices/${invoiceId}/cancel`);
  }

  public async resendInvoiceEmail(invoiceId: number, email?: string): Promise<void> {
    await this.request(
      'POST',
      `/invoices/${invoiceId}/resend-email`,
      email === undefined ? {} : { body: { email } }
    );
  }

  /** Processes a pending/confirming/out-of-stock invoice, delivering its items. */
  public async processInvoice(invoiceId: number, markAsPaid: boolean): Promise<void> {
    await this.request(
      'GET',
      `/invoices/${invoiceId}/process`,
      markAsPaid ? { query: { mark_as_paid: '1' } } : {}
    );
  }

  public async deliverInvoice(invoiceId: number): Promise<void> {
    await this.request('POST', `/invoices/${invoiceId}/deliver`);
  }

  public async updateInvoiceDashboardNote(invoiceId: number, note: string | null): Promise<void> {
    await this.request('PUT', `/invoices/${invoiceId}/dashboard-note`, { body: { note } });
  }

  public async shipInvoice(
    invoiceId: number,
    tracking: { readonly code?: string; readonly link?: string }
  ): Promise<void> {
    const body: Record<string, unknown> = {};
    if (tracking.code !== undefined) {
      body['tracking_code'] = tracking.code;
    }
    if (tracking.link !== undefined) {
      body['tracking_link'] = tracking.link;
    }
    await this.request('POST', `/invoices/${invoiceId}/ship`, { body });
  }

  public async unrefundInvoice(invoiceId: number): Promise<void> {
    await this.request('POST', `/invoices/${invoiceId}/unrefund`);
  }

  public async archiveInvoice(invoiceId: number): Promise<void> {
    await this.request('POST', `/invoices/${invoiceId}/archive`);
  }

  public async unarchiveInvoice(invoiceId: number): Promise<void> {
    await this.request('POST', `/invoices/${invoiceId}/unarchive`);
  }

  public async reverseCashback(invoiceId: number): Promise<void> {
    await this.request('POST', `/invoices/${invoiceId}/reverse-cashback`);
  }

  public async reverseAffiliateCommission(invoiceId: number): Promise<void> {
    await this.request('POST', `/invoices/${invoiceId}/reverse-affiliate-commission`);
  }

  public async createCheckoutSession(input: CreateCheckoutInput): Promise<CheckoutSession> {
    const body: Record<string, unknown> = { cart: input.cart };
    if (input.email !== undefined) {
      body['email'] = input.email;
    }
    if (input.coupon !== undefined) {
      body['coupon'] = input.coupon;
    }
    if (input.currency !== undefined) {
      body['currency'] = input.currency;
    }
    return this.request<CheckoutSession>('POST', '/checkout', { body });
  }

  public async getBlacklist(
    page: number,
    perPage: number,
    value?: string
  ): Promise<BlacklistPage> {
    const params: Record<string, string> = {
      page: String(page),
      perPage: String(perPage)
    };
    if (value !== undefined) {
      params['value'] = value;
    }
    return this.get<BlacklistPage>('/blacklist', params);
  }

  public async createBlacklistEntry(input: CreateBlacklistEntryInput): Promise<BlacklistEntry> {
    const body: Record<string, unknown> = {
      value: input.value,
      type: input.type,
      match_type: 'exact'
    };
    if (input.reason !== undefined) {
      body['reason'] = input.reason;
    }
    return this.request<BlacklistEntry>('POST', '/blacklist', { body });
  }

  public async deleteBlacklistEntry(entryId: number): Promise<void> {
    await this.request('DELETE', `/blacklist/${entryId}`);
  }

  public async getTickets(query: TicketListQuery): Promise<TicketPage> {
    const params: Record<string, string> = {
      page: String(query.page),
      perPage: String(query.perPage),
      orderColumn: 'created_at',
      orderDirection: 'desc'
    };
    if (query.status !== undefined) {
      params['statuses[]'] = query.status;
    }
    if (query.email !== undefined) {
      params['customer_email'] = query.email;
    }
    return this.get<TicketPage>('/tickets', params);
  }

  public async getTicket(ticketId: string): Promise<TicketDetail> {
    return this.get<TicketDetail>(`/tickets/${encodeURIComponent(ticketId)}`);
  }

  public async sendTicketMessage(ticketId: string, content: string): Promise<void> {
    await this.request('POST', `/tickets/${encodeURIComponent(ticketId)}/messages`, {
      body: { content }
    });
  }

  public async closeTicket(ticketId: string): Promise<void> {
    await this.request('POST', `/tickets/${encodeURIComponent(ticketId)}/close`);
  }

  public async reopenTicket(ticketId: string): Promise<void> {
    await this.request('POST', `/tickets/${encodeURIComponent(ticketId)}/reopen`);
  }

  public async getFeedbacks(query: FeedbackListQuery): Promise<FeedbackPage> {
    const params: Record<string, string> = {
      page: String(query.page),
      perPage: String(query.perPage),
      orderColumn: 'created_at',
      orderDirection: 'desc'
    };
    if (query.rating !== undefined) {
      params['rating'] = String(query.rating);
    }
    if (query.writtenOnly === true) {
      params['is_automatic'] = '0';
    }
    return this.get<FeedbackPage>('/feedbacks', params);
  }

  public async getFeedbackStats(): Promise<FeedbackStats> {
    return this.get<FeedbackStats>('/feedbacks/stats');
  }

  public async replyToFeedback(feedbackId: number, reply: string): Promise<void> {
    await this.request('POST', `/feedbacks/${feedbackId}/reply`, { body: { reply } });
  }

  public async getCoupons(page: number, perPage: number): Promise<CouponPage> {
    return this.get<CouponPage>('/coupons', { page: String(page), perPage: String(perPage) });
  }

  public async createCoupon(input: CreateCouponInput): Promise<Coupon> {
    const body: Record<string, unknown> = {
      code: input.code,
      global: true,
      discount: input.discount,
      type: input.type
    };
    if (input.maxUses !== undefined) {
      body['max_uses'] = input.maxUses;
    }
    if (input.maxUsesPerCustomer !== undefined) {
      body['max_uses_per_customer'] = input.maxUsesPerCustomer;
    }
    if (input.minInvoicePrice !== undefined) {
      body['min_invoice_price'] = input.minInvoicePrice;
    }
    if (input.expirationDate !== undefined) {
      body['expiration_date'] = input.expirationDate;
    }
    return this.request<Coupon>('POST', '/coupons', { body });
  }

  public async deleteCoupon(couponId: number): Promise<void> {
    await this.request('DELETE', `/coupons/${couponId}`);
  }

  /**
   * Replaces delivered entries of an invoice item. Keys of `replacements` are
   * zero-based indexes into the item's delivered array; the special value
   * "STOCK" pulls a fresh serial from the product's stock.
   */
  public async replaceDelivered(
    invoiceId: number,
    invoiceItemId: number,
    replacements: Readonly<Record<number, string>>
  ): Promise<void> {
    await this.request('POST', `/invoices/${invoiceId}/replace-delivered`, {
      body: { invoice_item_id: invoiceItemId, replacements }
    });
  }

  /** Calls the dynamic delivery endpoint of an invoice item again. */
  public async redoDynamicDelivery(invoiceId: number, invoiceItemId: number): Promise<void> {
    await this.request('POST', `/invoices/${invoiceId}/redo-dynamic-delivery`, {
      body: { invoice_item_id: invoiceItemId }
    });
  }

  /** Adds (positive) or deducts (negative) customer balance. Range: -1000 to 1000. */
  public async editCustomerBalance(
    customerId: number,
    amount: number,
    description?: string
  ): Promise<void> {
    const body: Record<string, unknown> = { amount };
    if (description !== undefined) {
      body['description'] = description;
    }
    await this.request('PUT', `/customers/${customerId}/balance`, { body });
  }

  public async getCustomerBalanceTransactions(
    customerId: number,
    page: number,
    perPage: number
  ): Promise<BalanceTransactionPage> {
    return this.get<BalanceTransactionPage>(`/customers/${customerId}/balance-transactions`, {
      page: String(page),
      perPage: String(perPage)
    });
  }

  public async findCustomerByEmail(email: string): Promise<CustomerSummary | null> {
    const page = await this.get<CustomerPage>('/customers', { email });
    return page.data[0] ?? null;
  }

  public async getInvoicesByEmail(
    email: string,
    page: number,
    perPage: number
  ): Promise<InvoicePage> {
    return this.get<InvoicePage>('/invoices', {
      email,
      page: String(page),
      perPage: String(perPage)
    });
  }

  /** Sets or clears (with nulls) the storefront status badge of products. */
  public async updateProductStatuses(
    target: 'all' | { readonly productIds: readonly number[] },
    statusText: string | null,
    statusColor: string | null
  ): Promise<void> {
    const body: Record<string, unknown> = {
      status_text: statusText,
      status_color: statusColor
    };
    if (target === 'all') {
      body['all'] = true;
    } else {
      body['product_ids'] = target.productIds;
    }
    await this.request('PUT', '/products/bulk-update/status', { body });
  }

  public async getBlacklistLogs(page: number, perPage: number): Promise<BlacklistLogPage> {
    return this.get<BlacklistLogPage>('/blacklist-logs', {
      page: String(page),
      perPage: String(perPage)
    });
  }

  public async getWhitelist(page: number, perPage: number, value?: string): Promise<WhitelistPage> {
    const params: Record<string, string> = { page: String(page), perPage: String(perPage) };
    if (value !== undefined) {
      params['value'] = value;
    }
    return this.get<WhitelistPage>('/whitelist', params);
  }

  public async createWhitelistEntry(input: {
    readonly value: string;
    readonly type: string;
    readonly reason?: string;
  }): Promise<WhitelistEntry> {
    const body: Record<string, unknown> = { value: input.value, type: input.type };
    if (input.reason !== undefined) {
      body['reason'] = input.reason;
    }
    return this.request<WhitelistEntry>('POST', '/whitelist', { body });
  }

  public async deleteWhitelistEntry(entryId: number): Promise<void> {
    await this.request('DELETE', `/whitelist/${entryId}`);
  }

  /** Disputes a feedback so SellAuth staff review it. */
  public async disputeFeedback(feedbackId: number, reason: string): Promise<void> {
    await this.request('POST', `/feedbacks/${feedbackId}/dispute`, { body: { reason } });
  }

  public async cancelFeedbackDispute(feedbackId: number): Promise<void> {
    await this.request('POST', `/feedbacks/${feedbackId}/cancel-dispute`);
  }

  /** Deletes every automatic (system-generated) feedback. Irreversible. */
  public async deleteAutomaticFeedbacks(): Promise<void> {
    await this.request('POST', '/feedbacks/delete-automatic');
  }

  public async getWebhookLogs(options: {
    readonly page: number;
    readonly perPage: number;
    readonly failedOnly?: boolean;
    readonly source?: 'notification' | 'dynamic_delivery';
    readonly invoiceId?: string;
  }): Promise<WebhookLogPage> {
    const params: Record<string, string> = {
      page: String(options.page),
      perPage: String(options.perPage)
    };
    if (options.failedOnly === true) {
      params['success'] = '0';
    }
    if (options.source !== undefined) {
      params['source'] = options.source;
    }
    if (options.invoiceId !== undefined) {
      params['invoice_id'] = options.invoiceId;
    }
    return this.get<WebhookLogPage>('/webhook-logs', params);
  }

  /** Full update - the API replaces all listed fields, so pass merged values. */
  public async updateCoupon(couponId: number, input: UpdateCouponInput): Promise<void> {
    await this.request('PUT', `/coupons/${couponId}/update`, {
      body: {
        code: input.code,
        global: input.global,
        discount: input.discount,
        type: input.type,
        max_uses: input.maxUses,
        max_uses_per_customer: input.maxUsesPerCustomer,
        min_invoice_price: input.minInvoicePrice,
        expiration_date: input.expirationDate
      }
    });
  }

  public async getSubscriptions(
    page: number,
    perPage: number,
    status?: string
  ): Promise<SubscriptionPage> {
    const params: Record<string, string> = { page: String(page), perPage: String(perPage) };
    if (status !== undefined) {
      params['status'] = status;
    }
    return this.get<SubscriptionPage>('/subscriptions', params);
  }

  public async getSubscription(subscriptionId: number): Promise<SubscriptionDetail> {
    return this.get<SubscriptionDetail>(`/subscriptions/${subscriptionId}`);
  }

  public async cancelSubscription(subscriptionId: number, atPeriodEnd: boolean): Promise<void> {
    await this.request('POST', `/subscriptions/${subscriptionId}/cancel`, {
      body: { at_period_end: atPeriodEnd }
    });
  }

  /** Sets the stock count of a service or dynamic product variant (-1 = unlimited). */
  public async updateVariantStock(
    productId: number,
    variantId: number,
    stock: number
  ): Promise<void> {
    await this.request('PUT', `/products/${productId}/stock/${variantId}`, { body: { stock } });
  }

  public async archiveTicket(ticketId: string): Promise<void> {
    await this.request('POST', `/tickets/${ticketId}/archive`);
  }

  public async unarchiveTicket(ticketId: string): Promise<void> {
    await this.request('POST', `/tickets/${ticketId}/unarchive`);
  }

  /** Sets the storefront visibility of products via the bulk endpoint. */
  public async updateProductVisibilities(
    target: 'all' | { readonly productIds: readonly number[] },
    visibility: 'public' | 'unlisted' | 'private' | 'on_hold'
  ): Promise<void> {
    const body: Record<string, unknown> = { visibility };
    if (target === 'all') {
      body['all'] = true;
    } else {
      body['product_ids'] = target.productIds;
    }
    await this.request('PUT', '/products/bulk-update/visibility', { body });
  }

  public async getAbandonedCheckouts(page: number, perPage: number): Promise<AbandonedCheckoutPage> {
    return this.get<AbandonedCheckoutPage>('/abandoned-checkouts', {
      page: String(page),
      perPage: String(perPage)
    });
  }

  public async getAbandonedCheckoutStats(): Promise<AbandonedCheckoutStats> {
    return this.get<AbandonedCheckoutStats>('/abandoned-checkouts/stats');
  }

  /** Sends a recovery email for an abandoned checkout, optionally attaching a coupon. */
  public async recoverAbandonedCheckout(invoiceId: number, couponId?: number): Promise<void> {
    await this.request(
      'POST',
      `/abandoned-checkouts/${invoiceId}/recover`,
      couponId === undefined ? {} : { body: { coupon_id: couponId } }
    );
  }

  public async getPaymentMethods(): Promise<readonly PaymentMethod[]> {
    const page = await this.get<{ data: readonly PaymentMethod[] }>('/payment-methods');
    return page.data;
  }

  /** Flips the active status of a payment method. */
  public async togglePaymentMethod(paymentMethodId: number): Promise<void> {
    await this.request('POST', `/payment-methods/${paymentMethodId}/toggle`);
  }

  public async getTrafficStats(range: DateRange): Promise<TrafficStats> {
    return this.get<TrafficStats>('/analytics/traffic/stats', dateRangeParams(range));
  }

  public async getActiveVisitors(): Promise<number> {
    const result = await this.get<{ visitors: number }>('/analytics/traffic/active');
    return result.visitors;
  }

  public async getTrafficUtm(range: DateRange): Promise<TrafficUtmBreakdown> {
    return this.get<TrafficUtmBreakdown>('/analytics/traffic/utm', dateRangeParams(range));
  }

  public async getLatestNotifications(): Promise<LatestNotifications> {
    return this.get<LatestNotifications>('/notifications/latest');
  }

  public async getActivityLogs(page: number, perPage: number): Promise<ActivityLogPage> {
    return this.get<ActivityLogPage>('/activity-logs', {
      page: String(page),
      perPage: String(perPage)
    });
  }

  public async getAffiliates(page: number, perPage: number, search?: string): Promise<AffiliatePage> {
    const params: Record<string, string> = { page: String(page), perPage: String(perPage) };
    if (search !== undefined) {
      params['search'] = search;
    }
    return this.get<AffiliatePage>('/affiliates', params);
  }

  public async getAffiliateStats(): Promise<AffiliateStats> {
    return this.get<AffiliateStats>('/affiliates/stats');
  }

  public async getAffiliate(customerId: number): Promise<AffiliateDetail> {
    return this.get<AffiliateDetail>(`/affiliates/${customerId}`);
  }

  public async inviteAffiliate(email: string, code: string, tierId: number): Promise<void> {
    await this.request('POST', '/affiliates/invite', {
      body: { email, affiliate_code: code, tier_id: tierId }
    });
  }

  public async suspendAffiliate(customerId: number): Promise<void> {
    await this.request('POST', `/affiliates/${customerId}/suspend`);
  }

  public async restoreAffiliate(customerId: number): Promise<void> {
    await this.request('POST', `/affiliates/${customerId}/restore`);
  }

  public async getAffiliateTiers(): Promise<readonly AffiliateTier[]> {
    return this.get<readonly AffiliateTier[]>('/affiliate-tiers');
  }

  public async getAffiliatePayouts(
    perPage: number,
    status?: 'pending' | 'paid' | 'rejected' | 'cancelled'
  ): Promise<AffiliatePayoutPage> {
    const params: Record<string, string> = { perPage: String(perPage) };
    if (status !== undefined) {
      params['status'] = status;
    }
    return this.get<AffiliatePayoutPage>('/affiliate-payouts', params);
  }

  /** Marks a pending payout request as paid (the actual money moves outside SellAuth). */
  public async payAffiliatePayout(payoutRequestId: number): Promise<void> {
    await this.request('POST', `/affiliate-payouts/${payoutRequestId}/pay`);
  }

  /** Rejects a pending payout request and refunds the amount to the affiliate balance. */
  public async rejectAffiliatePayout(payoutRequestId: number, note?: string): Promise<void> {
    await this.request(
      'POST',
      `/affiliate-payouts/${payoutRequestId}/reject`,
      note === undefined ? {} : { body: { seller_note: note } }
    );
  }

  public async getResellers(
    page: number,
    perPage: number,
    options: { readonly status?: string; readonly search?: string } = {}
  ): Promise<ResellerPage> {
    const params: Record<string, string> = { page: String(page), perPage: String(perPage) };
    if (options.status !== undefined) {
      params['status'] = options.status;
    }
    if (options.search !== undefined) {
      params['search'] = options.search;
    }
    return this.get<ResellerPage>('/resellers', params);
  }

  public async getResellerStats(): Promise<ResellerStats> {
    return this.get<ResellerStats>('/resellers/stats');
  }

  public async getReseller(customerId: number): Promise<ResellerDetail> {
    return this.get<ResellerDetail>(`/resellers/${customerId}`);
  }

  public async inviteReseller(email: string, tierId: number): Promise<void> {
    await this.request('POST', '/resellers/invite', { body: { email, tier_id: tierId } });
  }

  public async approveReseller(customerId: number, tierId: number): Promise<void> {
    await this.request('POST', `/resellers/${customerId}/approve`, { body: { tier_id: tierId } });
  }

  public async rejectReseller(customerId: number): Promise<void> {
    await this.request('POST', `/resellers/${customerId}/reject`);
  }

  public async suspendReseller(customerId: number): Promise<void> {
    await this.request('POST', `/resellers/${customerId}/suspend`);
  }

  public async restoreReseller(customerId: number): Promise<void> {
    await this.request('POST', `/resellers/${customerId}/restore`);
  }

  public async getResellerTiers(): Promise<readonly ResellerTier[]> {
    return this.get<readonly ResellerTier[]>('/reseller-tiers');
  }

  private async get<T>(path: string, query?: QueryParams): Promise<T> {
    return this.request<T>('GET', path, { query });
  }

  private async request<T>(
    method: 'GET' | 'POST' | 'PUT' | 'DELETE',
    path: string,
    options: {
      query?: QueryParams | undefined;
      body?: Readonly<Record<string, unknown>> | undefined;
    } = {}
  ): Promise<T> {
    const url = new URL(`${this.baseUrl}/shops/${this.shopId}${path}`);
    for (const [key, value] of Object.entries(options.query ?? {})) {
      url.searchParams.set(key, value);
    }

    const headers: Record<string, string> = {
      Authorization: `Bearer ${this.apiKey}`,
      Accept: 'application/json'
    };
    if (options.body !== undefined) {
      headers['Content-Type'] = 'application/json';
    }

    const response = await fetch(url, {
      method,
      headers,
      body: options.body === undefined ? null : JSON.stringify(options.body)
    });

    if (!response.ok) {
      const body = await response.text();
      throw new SellAuthApiError(
        response.status,
        `SellAuth API ${method} ${path} failed with status ${response.status}: ${body}`,
        extractApiMessage(body)
      );
    }

    const text = await response.text();
    // Action endpoints can return an empty body on success.
    return (text === '' ? undefined : JSON.parse(text)) as T;
  }
}
