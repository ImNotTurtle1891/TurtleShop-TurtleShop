# SellBot

A self-hosted Discord bot for [SellAuth](https://sellauth.com) shop owners — run your whole shop from Discord. Stats and revenue analytics, product browsing, customer and order lookups, an order-claiming system that hands out a customer role, support tickets, reviews, coupons, blacklist management, and invoice creation, all as slash commands with configurable admin/support/everyone permissions.

## Showcase

Restocking a product with `/restock` — paste the keys (or attach a `.txt`), and the bot adds them to stock and deletes the message:

![Restocking a product with /restock](https://i.imgur.com/Yfmi89w.gif)

## Commands (Total: 94)

| Command | Description |
| --- | --- |
| `/stats` | Lifetime shop statistics: products sold, customers, completed orders, feedback count, and average rating. |
| `/analytics [timeframe]` | Revenue, orders, and customers for a timeframe, with change vs. the previous period. |
| `/top products [timeframe]` | Top 10 products by revenue. |
| `/top customers [timeframe]` | Top 10 customers by revenue (emails are masked). |
| `/top payment-methods [timeframe]` | Top payment methods by revenue. |
| `/products [search] [page]` | Browse products with prices and stock counts, optionally filtered by name. |
| `/product <name>` | Detailed view of one product with per-variant prices and stock. The name option autocompletes from your live catalog. |
| `/commands` | List all SellBot commands and the permission level each one requires. |
| `/redeemorder <orderid>` | Customers verify a completed order and receive the customer role. |
| `/claimorder-embed` | Admins post a permanent embed with a "Claim Order" button that opens an order-ID form. |
| `/customer <email>` | Look up a customer: spend, balance, Discord account, and their full order history with ◀ ▶ pagination. |
| `/order check <id>` | Full details of one order: status, total, payment method, customer, items, feedback, IP, blacklist flags, and who claimed it. Accepts the numeric or unique invoice ID. |
| `/order complete <id>` | Mark an order as completed. |
| `/order refund <id>` | Mark an order as refunded (does not move money — process the actual refund with your payment provider). |
| `/order cancel <id>` | Mark an order as cancelled. |
| `/order resend-email <id> [email]` | Resend the order confirmation email, optionally to a different address. |
| `/order process <id> [mark_as_paid]` | Deliver the items of a stuck pending or out-of-stock order, optionally marking it as paid. |
| `/order deliver <id>` | Re-deliver the order items and notify the customer. |
| `/order note <id> <text>` | Set the dashboard note of an order. |
| `/order ship <id> [tracking_code] [tracking_link]` | Mark an order as shipped, optionally with tracking info. |
| `/order unrefund <id>` | Remove the refunded status from an order. |
| `/order archive <id>` / `/order unarchive <id>` | Archive or unarchive an order. |
| `/order reverse-cashback <id>` | Reverse the cashback a customer earned on an order (e.g. after a chargeback). |
| `/order reverse-affiliate-commission <id>` | Reverse the affiliate commission earned on an order. |
| `/order replace-delivered <id> <old> [new]` | Replace a bad delivered key: paste the key the customer received, and either provide the replacement or leave it empty to pull a fresh one from stock (serial-key products). |
| `/order redo-delivery <id> [item]` | Re-run dynamic delivery for an order item — the "customer didn't get access" fix for dynamic products. |
| `/balance view <email> [page]` | A customer's store credit and their balance transaction history. |
| `/balance add <email> <amount> [reason]` / `/balance remove <email> <amount> [reason]` | Add or deduct store credit (max 1000 per adjustment). The reason shows up in the ledger. |
| `/coupon list [page]` | List coupons with discount, usage counts, total savings, and expiry. |
| `/coupon create <code> <discount> <type> [...]` | Create an all-products coupon. Optional: max uses, uses per customer, minimum order value, expiry in days. |
| `/coupon edit <code> [...]` | Change a coupon's discount, type, use limits, minimum order, or expiry without recreating it. |
| `/coupon delete <code>` | Delete a coupon. The code option autocompletes from your live coupons. |
| `/blacklist list [page]` | List blacklist entries with type, reason, and date. |
| `/blacklist add <type> <value> [reason]` | Block an email, email domain, Discord ID, IP, IP range, country, city, ISP, ASN, or user agent. |
| `/blacklist remove <value>` | Remove a blacklist entry. Autocompletes from your live blacklist. |
| `/blacklist check <value>` | Check whether a value is blacklisted and why (support-level by default). |
| `/blacklist logs [page]` | Recent checkout attempts that were blocked, with the rule that caught them. |
| `/whitelist list\|add\|remove` | Exceptions that override blacklist rules — e.g. unblock one trusted customer on a blocked IP range. |
| `/createinvoice product <product> [...]` | Create an invoice for a catalog product and get a checkout link. The product option autocompletes with variants and prices. Optional: quantity, customer email, coupon. |
| `/createinvoice custom <name> <price> [...]` | Create an invoice for a one-off charge that is not in your catalog. Optional: currency, quantity, customer email, coupon. Requires a SellAuth plan with the Checkout API feature. |
| `/feedback recent [page] [rating] [written]` | Recent reviews, newest first. Filter by star rating or to customer-written reviews only. |
| `/feedback stats` | Rating breakdown with per-star bars, average, and reply rate. |
| `/feedback reply <id> <message>` | Post a public reply to a review (the ID is shown in `/feedback recent`). |
| `/feedback dispute <id> <reason>` / `/feedback cancel-dispute <id>` | Flag an unfair review for SellAuth staff review, or withdraw the dispute. |
| `/feedback purge-automatic <confirm>` | Permanently delete all automatic (system-generated) feedbacks. Customer-written reviews are kept. |
| `/ticket list [status] [email] [page]` | List support tickets, newest first, filterable by status or customer. |
| `/ticket view <id>` | A ticket with its recent messages. The ID option autocompletes by subject and customer. |
| `/ticket reply <id> <message>` | Send a message to a ticket as the shop. |
| `/ticket close <id>` / `/ticket reopen <id>` | Close or reopen a ticket. |
| `/ticket archive <id>` / `/ticket unarchive <id>` | Archive a ticket (hides it from the default list) or bring it back. |
| `/subscription list [status] [page]` | List customer subscriptions with price, interval, and renewal date. |
| `/subscription view <id>` / `/subscription cancel <id> [immediately]` | Subscription details, or cancel one (at period end by default). |
| `/setstock <product> <amount>` | Set the stock count of a dynamic/service variant (-1 for unlimited). For serial-key products use `/restock`. |
| `/product-visibility <product> <visibility>` | Set a product to public, unlisted, private, or on hold. |
| `/abandoned list [page]` / `/abandoned stats` | Abandoned checkouts with lost revenue, and recovery statistics. Requires a SellAuth plan with abandoned checkouts. |
| `/abandoned recover <id> [coupon]` | Send a recovery email for an abandoned checkout, optionally attaching a coupon as an incentive. |
| `/restock <product>` | Add serial keys to a serial-key product. The bot prompts you to send the keys in your next message (comma- or newline-separated, or a `.txt` attachment), adds them to the stock, then deletes your message. |
| `/stock [threshold]` | Stock overview across all products with out-of-stock and low-stock warnings (default threshold: 10, unlimited-stock variants are skipped). |
| `/status list` | Every product with its current storefront status badge, grouped by status. |
| `/status set <product> <text> [color]` | Set a product's status badge. Preset texts (Undetected, Updating, Down, …) and colors autocomplete; custom text and hex colors work too. Color defaults to a sensible match for the text. |
| `/status set-all <text> [color]` | Set the status badge of **every** product at once — flip the whole shop to "Updating" the moment a game patches. |
| `/status clear <product\|all>` | Remove the status badge from one product or all of them. |
| `/paymentmethods list` | List all payment methods with their status and fees. |
| `/paymentmethods toggle <method>` | Enable or disable a payment method — e.g. temporarily disable a gateway that is acting up. |
| `/traffic [timeframe]` | Live visitor count plus pageviews, visits, bounce rate, average visit time and UTM breakdown, with change vs. the previous period. |
| `/notifications [count]` | The latest dashboard notifications (sales, tickets, feedback, webhooks) with links to the dashboard. |
| `/activity [page]` | Audit log of dashboard and staff actions with what-changed summaries (e.g. `stock: 26 → 102`). |
| `/webhooklogs [failed] [source] [invoice] [page]` | Outgoing webhook and dynamic-delivery request logs with status, timing, and error messages. URLs are shown without query strings so secrets stay out of Discord. |
| `/affiliate list\|stats\|view` | Browse your affiliates, aggregate program stats, or one affiliate's earnings, referrals and payout requests. |
| `/affiliate invite <email> <code> [tier]` | Make a customer an affiliate. `suspend` / `restore` toggle an affiliate without losing their history. |
| `/affiliate payouts [status]` | List payout requests; approve with `/affiliate payout-pay <id>` (money moves outside SellAuth) or reject with `/affiliate payout-reject <id> [note]` (refunds their balance). |
| `/reseller list\|stats\|view` | Browse resellers and applications, program stats, or one reseller's profile and recent orders. Requires a SellAuth plan with the reseller panel. |
| `/reseller invite\|approve\|reject\|suspend\|restore` | Manage reseller applications and status. `invite` approves a customer immediately; `approve`/`reject` handle pending applications. |

Available timeframes: today, last 7/30/90/365 days, and all time. The default is the last 30 days.

All responses are ephemeral (only visible to the person who ran the command). Without any configuration, commands require the **Manage Server** permission. See [Configuration](#configuration) to use your own admin/support roles instead.

## Configuration

Copy `config.example.json` to `config.json` to control who can use which commands and where:

```json
{
  "roles": {
    "adminRoleIds": ["123456789012345678"],
    "supportRoleIds": ["234567890123456789"]
  },
  "commandPermissions": {
    "stats": "admin",
    "analytics": "admin",
    "top": "support",
    "top customers": "admin"
  },
  "allowedChannelIds": ["345678901234567890"],
  "customerRoleId": "456789012345678901"
}
```

> **Important:** always wrap Discord IDs in quotes. Unquoted numeric IDs get corrupted because they exceed JavaScript's safe integer range.

- **`roles.adminRoleIds` / `roles.supportRoleIds`** — Discord role IDs (right-click a role → Copy Role ID, with Developer Mode enabled). Members with an admin role can use everything; support roles only unlock commands set to `"support"`.
- **`commandPermissions`** — permission level per command: `"admin"`, `"support"`, or `"everyone"`. Commands not listed default to `"admin"`. Subcommands can override their parent with a `"command subcommand"` key — in the example above, support staff can use `/top products`, but `/top customers` stays admin-only.
- **`allowedChannelIds`** — channel or category IDs where commands are allowed. A category ID allows every channel inside it. Leave empty to allow commands everywhere.
- **`customerRoleId`** — the role granted when a member claims a completed order via `/redeemorder` or the claim button. Leave empty to disable order claiming. The bot needs the **Manage Roles** permission and its role must be *above* the customer role in your server's role list. Each order can only be claimed by one Discord user (tracked in `data/claims.json`).

Notes:

- Server Administrators always have access, so you can never lock yourself out.
- If no roles are configured for a level, that level falls back to requiring the **Manage Server** permission.
- After changing `config.json`, restart the bot and re-run `npm run deploy-commands` (command visibility in Discord's UI is set at registration time).
- `config.json` is gitignored since it contains your server-specific IDs.

## Requirements

- [Node.js](https://nodejs.org) 18 or newer
- A [SellAuth](https://sellauth.com) shop and API key
- A Discord application with a bot user

## Setup

### 1. Create a Discord application

1. Go to the [Discord Developer Portal](https://discord.com/developers/applications) and click **New Application**.
2. On the **Bot** tab, click **Reset Token** and copy the token — this is your `DISCORD_TOKEN`.
3. Still on the **Bot** tab, enable the **Message Content Intent** under *Privileged Gateway Intents* — `/restock` needs it to read the message containing your keys. Without it the bot refuses to log in.
4. On the **General Information** tab, copy the **Application ID** — this is your `DISCORD_CLIENT_ID`.
5. Invite the bot to your server using this URL (replace `YOUR_CLIENT_ID`):

```
https://discord.com/oauth2/authorize?client_id=YOUR_CLIENT_ID&scope=bot+applications.commands&permissions=268443648
```

The `permissions=268443648` part grants **Manage Roles** (needed by the order-claim feature to assign the customer role) and **Manage Messages** (needed by `/restock` to delete the message containing your keys after they are added).

### 2. Get your SellAuth credentials

1. Get your API key from the SellAuth dashboard under [Account → Developers](https://dash.sellauth.com/api) — this is your `SELLAUTH_API_KEY`.
2. Find your shop's numeric ID — this is your `SELLAUTH_SHOP_ID`.

### 3. Configure and run the bot

**Windows quick start:** double-click `startbot.bat`. It checks that Node.js is installed, creates a `.env` file for you to fill in on first run, then installs dependencies, validates your configuration, registers the slash commands, and starts the bot.

**Manual setup (all platforms):**

```bash
git clone https://github.com/YOUR_USERNAME/Sellauth-Discord-Bot.git
cd Sellauth-Discord-Bot
npm install

# Create your environment file and fill in the values from steps 1 and 2
cp .env.example .env

# Register the slash commands with Discord (run once, and again whenever commands change)
npm run deploy-commands

# Start the bot
npm run build
npm start
```

For development with automatic reload on file changes:

```bash
npm run dev
```

## Troubleshooting

**The bot replies or posts embeds twice, or logs `Unknown interaction` / `Interaction has already been acknowledged` errors.**
Two copies of the bot are running with the same token, and they race each other on every interaction. Common cause: `npm run dev` left running in one terminal while `startbot.bat` or `npm start` runs in another. Close all but one instance. If you can't find the extra instance (e.g. it's on another machine), reset the bot token in the [Discord Developer Portal](https://discord.com/developers/applications) — that disconnects everything, then start a single instance with the new token.

## Security notes

- Your `.env` file contains secrets. It is gitignored — never commit it or share its contents.
- Your SellAuth API key has full access to your shop. Only run this bot on machines you control.
- Customer emails are masked in `/top customers` output, but revenue data is still sensitive — keep the commands admin-only unless you're comfortable sharing it.

## Bug reports, suggestions, custom versions & hosting

Found a bug? Please report it so it can be fixed. Also get in touch if you have a feature suggestion, want a custom version of SellBot with extra functionality or changes tailored to your shop, or don't want to self-host and would rather have the bot hosted for you:

- **Discord:** `barkiegg`
- **Email:** [barkie.media@gmail.com](mailto:barkie.media@gmail.com)

## License

SellBot was made by **Barkie** ([barkiedev.cc](https://barkiedev.cc)) and is released under the [MIT License](LICENSE).

That means you're free to use, customize, self-host, and redistribute it however you want — build something good with it. The software is provided as-is: Barkie / barkiedev.cc is not responsible for anything that happens through your use of it, including (but not limited to) lost sales, misconfigured permissions, or actions taken on your SellAuth shop. See the [LICENSE](LICENSE) file for the full terms.
